<?php
  include "datos.php";

  $resultado = borrarNoticia($_POST['id']);
  header("location: index.php");
 ?>
